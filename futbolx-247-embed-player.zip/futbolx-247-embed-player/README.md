# FutbolX 24/7 MPEG-TS Embed Player

Standalone static player for the FutbolX **24/7 TV page only**.

## Included
- MPEG-TS playback via `mpegts.js`
- Custom play/pause, volume, fullscreen, Picture-in-Picture, and AirPlay controls where supported
- No custom “Connecting to channel” overlay
- No forced 16-second reconnect/reload loop
- Revalidating cache headers for the page and assets

## Deploy with GitHub + Vercel
1. Create a new GitHub repository, for example `futbolx-247-player`.
2. Upload all files in this folder to the repository root.
3. Import that repository into Vercel and deploy it as a static site.
4. Copy the Vercel deployment URL.

## Embed into `live-24-7.html`
Replace only the existing MPEG-TS player container in the 24/7 page, leaving unrelated page UI and logic unchanged. Pass the actual MPEG-TS stream URL already resolved by the current 24/7 page into the iframe.

```html
<iframe
  id="fx247Player"
  title="FutbolX 24/7 Player"
  allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
  allowfullscreen
  referrerpolicy="strict-origin-when-cross-origin"
  style="display:block;width:100%;aspect-ratio:16/9;border:0;background:#000"
></iframe>
```

In the page's existing JavaScript, after its MPEG-TS URL has been resolved (including any required token), set the iframe source:

```js
const playerEmbedBase = "https://YOUR-PLAYER-DEPLOYMENT.vercel.app/";
const iframe = document.getElementById("fx247Player");
iframe.src = playerEmbedBase + "?src=" + encodeURIComponent(actualMpegtsUrl);
```

`actualMpegtsUrl` must be the resolved MPEG-TS URL the current 24/7 page already uses. Keep existing token generation/renewal logic if required, and update the iframe `src` whenever that URL is refreshed. This service is MPEG-TS only; do not pass an iframe-player URL or event-page URL.

## Notes
- Browser autoplay policies may require muted autoplay or a user tap.
- The stream host must allow playback from this player origin when CORS is required.
- This player does not proxy the stream; the browser connects directly to the supplied stream URL.
- This package is prepared for deployment; it does not create a GitHub repository or deploy to Vercel automatically.
